import React, {useState} from 'react';

function Todo () {
  const [todo, setTodo] = useState([]);
  const [inputValue, setInputvalue] = useState('');

  const handleChange = (event) => {
    setInputvalue(event.target.value)
  };
  const addTodo = () => {
    if(inputValue.trim !== ('')) {
      setTodo ([...todo, inputValue ]);
      setInputvalue('');
    }
  };
  const deleteTodo = (index) => {
    const newTodo = [...todo];
    newTodo.splice(index, 1);
    setTodo(newTodo);
  };
  return (
    <div>
      <h1> Todo APP </h1>
      <input type="text" value={inputValue} onChange={handleChange} />
      <button onClick={addTodo}>ADD</button>
      <ul>
        {todo.map((todo, index) => (
          <li key={index}>
            {todo}
            <button onClick={ () => deleteTodo(index)}>Delete</button>
          
          </li>
        ))}    
      </ul>
    </div>
  );

}
export default Todo;